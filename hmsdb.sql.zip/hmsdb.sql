-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 12, 2018 at 06:02 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `hmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctorapp`
--

CREATE TABLE IF NOT EXISTS `doctorapp` (
  `fname` varchar(40) NOT NULL,
  `lname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `conatct` varchar(40) NOT NULL,
  `payement` varchar(40) NOT NULL,
  `docapp` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctorapp`
--

INSERT INTO `doctorapp` (`fname`, `lname`, `email`, `conatct`, `payement`, `docapp`) VALUES
('q', 'q', 'q', '0714716491', '', 'Dr Sharma from 6pm to 8pm'),
('thilina', 'madushan', 'jayawardana', 'smkmdldm', '', 'Dr Sharma from 6pm to 8pm'),
('thilina', 'jayawardana', 'thilinamjayawardana@gmail.com', '1', '', 'Dr Sharma from 6pm to 8pm'),
('a', 'b', 'thilinamjayawardana@gmail.com', 'sdsdsd', '', 'Dr Sharma from 6pm to 8pm'),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('ssd', 'sss', 'sddsd', 'sds', 'pay', 'Dr Sharma from 6pm to 8pm'),
('abc', 'cd', 'thilinmjayawardana@gmail.com', '0714716491', 'pay', 'Dr Sharma from 6pm to 8pm'),
('s', 's', 's', 's', 'pay', 'Dr Sharma from 6pm to 8pm'),
('ASAS', 'ASASASAS', 'AS', 'SA', 'pay', 'Dr Sharma from 6pm to 8pm'),
('aaaaaaaaaaaaaaaa', 'aaaaaaaaaaaaaaa', 'abc@gmail.com', '0714716491', 'pay', 'Dr Sharma from 6pm to 8pm');

-- --------------------------------------------------------

--
-- Table structure for table `logintb`
--

CREATE TABLE IF NOT EXISTS `logintb` (
  `username` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logintb`
--

INSERT INTO `logintb` (`username`, `password`) VALUES
('admin', 'pass');
